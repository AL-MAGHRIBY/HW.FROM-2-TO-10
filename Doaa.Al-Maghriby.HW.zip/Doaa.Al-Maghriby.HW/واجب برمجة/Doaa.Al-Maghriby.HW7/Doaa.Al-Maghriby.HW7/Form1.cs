﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW7
{
    public partial class Form1 : Form
    { //public formoperation();
        public Form1()
        {
            InitializeComponent();
        }
        formadd add;
        private void button1_Click(object sender, EventArgs e)
        {
            if (add == null || add.IsDisposed)
            {
                add = new formadd();
                add.Show();
            }
            else
            {
                add.Show();
            }
        }
        formsub sub;
        private void button2_Click(object sender, EventArgs e)
        {
            if (sub == null || sub.IsDisposed)
            {
                sub = new formsub();
                sub.Show();
            }
            else
            {
                sub.Show();
            }
        }
        formmul mul;
        private void button3_Click(object sender, EventArgs e)
        {
            if (mul == null || mul.IsDisposed)
            {
                mul = new formmul();
                mul.Show();
            }
            else
            {
                mul.Show();
            }
        }
        formdiv div;
        private void button4_Click(object sender, EventArgs e)
        {
            if (div == null || div.IsDisposed)
            {
                div = new formdiv();
                div.Show();
            }
            else
            {
                div.Show();
            }
        }

        private void حمعToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (add == null || add.IsDisposed)
            {
                add = new formadd();
                add.Show();
            }
            else
            {
                add.Show();
            }
        }

        private void طرحToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sub == null || sub.IsDisposed)
            {
                sub = new formsub();
                sub.Show();
            }
            else
            {
                sub.Show();
            }
        }

        private void ضربToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (mul == null || mul.IsDisposed)
            {
                mul = new formmul();
                mul.Show();
            }
            else
            {
                mul.Show();
            }
        }

        private void قسمةToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (div == null || div.IsDisposed)
            {
                div = new formdiv();
                div.Show();
            }
            else
            {
                div.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
