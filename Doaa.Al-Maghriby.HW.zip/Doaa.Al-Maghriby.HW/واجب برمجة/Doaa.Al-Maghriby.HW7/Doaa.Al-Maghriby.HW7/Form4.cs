﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW7
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        public string getname()
        {
            return textform4.Text;
        }
        public void updatename(string name)
        {
            textform4.Text = name;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            // Form3 form5 = new Form3();
            //Form5.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3("multiform");
            f.ShowDialog();
            f.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.setvalue(textform4.Text);
            f.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.textform3.Text = textform4.Text;
            f.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            Form3.staticvariable = textform4.Text;
            f.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            new Form3(textform4.Text).Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3(this);
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Form3 f = new Form3(listBox1);
            Form3 f = new Form3(listBox1.SelectedItem?.ToString() ?? ""); // تمرير النص المحدد من ListBox
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
          //  Form.Show();
        }
        Form3 formalobject;
        private void button7_Click(object sender, EventArgs e)
        {
            if (formalobject == null || formalobject.IsDisposed)
            {
                formalobject = new Form3();
                formalobject.Show();
            }
            else
            {
              //  formalobject.Show();
                formalobject.Focus();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
        }
    }
}
