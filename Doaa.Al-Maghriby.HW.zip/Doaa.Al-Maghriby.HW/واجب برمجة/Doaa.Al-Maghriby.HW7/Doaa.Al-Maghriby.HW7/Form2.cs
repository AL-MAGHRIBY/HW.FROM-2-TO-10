﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW7
{
    public partial class Form2 : Form
    {
        Button b;
        Label l;
        TextBox t;
        ListBox lst;
        public Form2()
        {
            InitializeComponent();
            b = new Button();
            l = new Label();
            lst = new ListBox();
            t = new TextBox();
            b.Click += bclick;
        }

        public Form2(string btntext, string lbltext)
        {
            InitializeComponent();
            b = new Button();
            l = new Label();
            lst = new ListBox();
            t = new TextBox();
            b.Text = btntext;
            l.Text = lbltext;
            b.Click += bclick;
        }

        public void set(string btntext, string lbltext)
        {
            b.Text = btntext;
            l.Text = lbltext;
        }
        public void bclick(object s, EventArgs e)
        {
            lst.Items.Add(t.Text);
        }
        public void disgin()
        {
            t.Top = 10; t.Left = 10;
            l.Top = 10; l.Left = 110;
            b.Top = 30; b.Left = 25;
            lst.Top = 60; lst.Left = 10;
        }
        public void visual()
        {
            this.Controls.Add(b);
            this.Controls.Add(l);
            this.Controls.Add(t);
            this.Controls.Add(lst);
        }
        public string getbtmtext()
        {
            return b.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 g = new Form2();
            g.disgin();
            g.visual();
            g.Show();
        }

        private void Form2_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2("add", "insert item");
            MessageBox.Show(f1.getbtmtext());
            f1.disgin();
            f1.visual();
            f1.StartPosition = FormStartPosition.Manual;  // لتحديد الموقع يدويًا
            f1.Location = new Point(this.Location.X + this.Width + 10, this.Location.Y);  // بجانب النموذج الرئيسي

            f1.Show();
            Form2 f2 = new Form2();
            f2.set("اضافة", "ادخل العنصر");
            f2.disgin();
            f2.visual();
            f2.StartPosition = FormStartPosition.Manual;
            f2.Location = new Point(f1.Location.X + f1.Width + 10, f1.Location.Y); // بجانب f1
            f2.Show();
        }
    }
}
