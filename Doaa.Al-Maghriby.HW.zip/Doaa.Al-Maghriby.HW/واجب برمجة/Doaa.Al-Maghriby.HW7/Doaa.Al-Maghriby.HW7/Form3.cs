﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW7
{
    public partial class Form3 : Form
    {
        public static string staticvariable = "";
        public Form3()
        {
            InitializeComponent();
        }
        public Form3(string name)
        {
            InitializeComponent();
            this.Text = name;
        }
        Form4 objf4;
        public Form3(Form4 objectform4)
        {
            InitializeComponent();
            textform3.Text = objectform4.getname();
            textform3.Text = objectform4.textform4.Text;
            objf4 = objectform4;
        }
        public void setvalue (string name)
        {
            textform3.Text = name;
        }
        public string getvalue()
        {
            return textform3.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textform3.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (objf4 != null)
            {
                objf4.updatename(getvalue());  
            }
            else
            {
                MessageBox.Show("Form4 is not available.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
