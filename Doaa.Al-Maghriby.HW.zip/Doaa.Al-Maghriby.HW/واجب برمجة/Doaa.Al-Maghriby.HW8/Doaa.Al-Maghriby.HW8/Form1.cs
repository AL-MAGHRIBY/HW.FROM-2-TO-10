﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text.Trim().Length.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0)
            {
                textBox3.Text = textBox1.SelectionLength.ToString();
            }
            else
            {
                MessageBox.Show("قم بتحديد النص");
                textBox3.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] strword = textBox1.Text.Trim().Split(' ');
            textBox4.Text = (strword.Length - 1).ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
            {
                textBox1.SelectedText = "";
            }
            else
            {
                MessageBox.Show("قم بتحديد النص");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.SelectionLength = 0;
        }
        string myselectedtext = "";

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0)
            {
                myselectedtext = textBox1.SelectedText;
            }
            else
            {
                MessageBox.Show("لا يوجد نص محدد ");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0)
            {
                textBox1.SelectedText = null;
            }
            else
            {
                MessageBox.Show("لا يوجد نص محدد ");
               // textBox1.Cut();
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox7.Text += myselectedtext.Trim();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.Undo();
            textBox7.Undo();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int x = 0;
            for (int i=0;i<textBox1.Text.Length;i++)
            {
                if (textBox1.Text[i] != ' ')
                {
                    x++;
                }
            }
            MessageBox.Show(x.ToString());
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int x = 0;
            for (int i = 0; i < textBox1.SelectedText.Length; i++)
            {
                if (textBox1.SelectedText[i] != ' ')
                {
                    x++;
                }
            }
            MessageBox.Show(x.ToString());
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
            {
                if (textBox5.Text.Trim() != "")
                {
                    textBox1.SelectedText = textBox5.Text;
                }
                else
                    MessageBox.Show("ادخل النص الجديد ");
            }
            else
                MessageBox.Show("حدد النص المراد تعديله  ");
        
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (textBox6.Text.Trim() != "")
            {
                int index = textBox1.Text.IndexOf(textBox6.Text, 0);
                if (index >-1)
                {
                    textBox1.SelectionStart = index;
                    textBox1.SelectionStart = textBox6.Text.Length;
                    textBox1.Focus();
                }
                else
                    MessageBox.Show("not found ");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه ");
                textBox6.Focus();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (textBox6.Text.Trim() !="")
            {
                int index = textBox1.Text.IndexOf(textBox6.Text, textBox1.SelectionStart + textBox1.SelectionLength);
                if (index > -1)
                {
                    textBox1.Focus();
                    textBox1.Select(index, textBox6.Text.Length);
                }
                else
                    MessageBox.Show("not found "); 
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه ");
                textBox6.Focus();
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (textBox6.Text.Trim() != "")
            {
                int index = textBox1.Text.LastIndexOf(textBox6.Text, textBox1.SelectionStart - textBox1.SelectionLength);
                if (index > -1)
                {
                    textBox1.Focus();
                    textBox1.Select(index, textBox6.Text.Length);
                }
                else
                    MessageBox.Show("not found ");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه ");
                textBox6.Focus();
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string s = textBox1.SelectedText;
            char[] ch = s.ToCharArray();
            for (int i = 0; i < ch.Length; i++)
                listBox1.Items.Add(ch[i]);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            string[] s = textBox1.SelectedText.Split(' ');
            for (int i = 0; i < s.Length; i++)
                listBox2.Items.Add(s[i]);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
