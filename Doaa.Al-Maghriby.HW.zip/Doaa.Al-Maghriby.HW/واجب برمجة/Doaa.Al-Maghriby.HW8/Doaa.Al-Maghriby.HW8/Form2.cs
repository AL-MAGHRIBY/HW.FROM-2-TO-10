﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW8
{
    public partial class Form2 : Form
    {
        private Stack<string> undoStack = new Stack<string>();
        private const int MaxUndo = 10;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.SelectedText))
            {
                Clipboard.SetText(textBox1.SelectedText);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.SelectedText))
            {
                AddToUndoStack(textBox1.Text);
                Clipboard.SetText(textBox1.SelectedText);
                textBox1.Text = textBox1.Text.Remove(textBox1.SelectionStart, textBox1.SelectionLength);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                AddToUndoStack(textBox2.Text);
                int start = textBox2.SelectionStart;
                textBox2.Text = textBox2.Text.Insert(start, Clipboard.GetText());
                textBox2.SelectionStart = start + Clipboard.GetText().Length;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (undoStack.Count > 0)
            {
                textBox2.Text = undoStack.Pop();
            }
        }
        private void AddToUndoStack(string text)
        {
            if (undoStack.Count >= MaxUndo)
            {
                undoStack.Clear();
            }
            undoStack.Push(text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

