﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW8
{
    public partial class Form3 : Form
    {
        private List<int> numbers = new List<int>();
        private const int MaxItems = 20;
        public Form3()
        {
            InitializeComponent();
        }

        private void InitializeList()
        {
            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                int randomNum;
                do
                {
                    randomNum = random.Next(1, 101);  // Generates numbers from 1 to 100
                }
                while (numbers.Contains(randomNum));
                numbers.Add(randomNum);
            }
            UpdateListBox();
        }

        private void UpdateListBox()
        {
            listBox1.Items.Clear();
            foreach (var num in numbers)
            {
                listBox1.Items.Add(num);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            int number;
            if (int.TryParse(textBox1.Text, out number))
            {
                if (number > 100)
                {
                    MessageBox.Show("Please enter a number less than or equal to 100.");
                    return;
                }

                if (!numbers.Contains(number))
                {
                    if (numbers.Count >= MaxItems)
                    {
                        numbers.RemoveAt(0); // Remove the oldest item if we exceed MaxItems
                    }
                    numbers.Add(number);
                    UpdateListBox();
                    textBox1.Clear();
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("The number is already in the list.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                numbers.Remove((int)listBox1.SelectedItem);
                UpdateListBox();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            numbers.Clear();
            UpdateListBox();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int sum = numbers.Sum();
            textBox2.Text = sum.ToString();
          
           // MessageBox.Show("Sum of the list items: " + sum);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (numbers.Count > 0)
            {
                double average = numbers.Average();
                textBox3.Text = average.ToString("F2");
            }
            else
            {
                textBox3.Text = "0.00";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

