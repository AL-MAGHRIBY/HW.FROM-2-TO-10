﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Size = new Size(895, 267);

            Random r = new Random();
            for (int x = 0; x < 10; x++)
            {
                int n = r.Next(100);
                listBox1.Items.Add(n);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (isNumoric(textBox1.Text.Trim()))
            {
                if (!repeated(listBox1, textBox1.Text))
                {
                    listBox1.Items.Add(textBox1.Text);
                    textBox1.Clear();
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("الرقم موجود مسبقاً");
                    textBox1.Clear();
                    textBox1.Focus();
                }
            }
            else
            {
                MessageBox.Show("يجب ان يكون المدخل رقماً");
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int c = listBox1.SelectedItems.Count;
            for (int i = 0; i < c; i++)
            {
                if (!repeated(listBox2, listBox1.SelectedItems[0].ToString()))
                {
                    listBox2.Items.Add(listBox1.Items[listBox1.SelectedIndex]);
                    listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            int c = listBox1.Items.Count;
            for (int i = 0; i < c; i++)
            {
                if (!listBox2.Items.Contains(listBox1.Items[0]))
                {
                    listBox2.Items.Add(listBox1.Items[0]);
                    listBox1.Items.Remove(listBox1.Items[0]);
                }
            }
        }

        bool isNumoric(string element)
        {
            if (element == "") return false;
            for (int i = 0; i < element.Length; i++)
            {
                if (element[i] < 48 || element[i] > 57)
                    return false;
            }
            return true;
        }
        bool repeated(ListBox l, string s)
        {
            for (int i = 0; i < l.Items.Count; i++)
            {
                if (l.Items[i].ToString() == s)
                    return true;
            }
            return false;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            sortAnylistBox(listBox1);
        }
        private void revers(ListBox listBox)
        {
            var items = listBox.Items.Cast<int>().Reverse().ToList();
            listBox.Items.Clear();
            foreach (var item in items)
            {
                listBox.Items.Add(item);
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox1);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex= -1;
            if (radioButton1.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 == 0)
                        listBox1.SelectedIndex = i;
                }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("لا توجد عناصر زوجية");
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            if (radioButton2.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 != 0)
                        listBox1.SelectedIndex = i;
                }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("لا توجد عناصر فردية");
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            
                listBox1.SelectedIndex = -1;
                bool flag = true;
                if (radioButton3.Checked)
                {
                    for (int i = 0; i < listBox1.Items.Count; i++)
                    {
                        int n = Convert.ToInt32(listBox1.Items[i]);
                        flag = true;
                        for (int j = 2; j < n; j++)
                        {
                            if (n % j == 0)
                            {
                                flag = false;
                                break;
                            }
                        }
                        if (flag)
                            listBox1.SelectedIndex = i;
                    }

                    if (listBox1.SelectedIndex == -1)
                        MessageBox.Show("لا توجد عناصر اولية");
                }
            
        }       
        private void button15_Click(object sender, EventArgs e)
        {
            if (button4.Text == "v")
            {
                this.Size = new Size(895, 802);
                button4.Text = "^";
            }
            else
            {
                this.Size = new Size(895, 267);
                button4.Text = "v";
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }
        private void sortAnylistBox(ListBox l)
        {
            int t; int c = l.Items.Count;
            for (int i = 0; i < c; i++)
            {
                for (int j = i + 1; j < c; j++)
                {
                    int n1 = Convert.ToInt32(l.Items[i]);
                    int n2 = Convert.ToInt32(l.Items[j]);
                    if (n1 < n2)
                    {
                        t = n1;
                        l.Items[i] = n2;
                        l.Items[j] = t;
                    }

                }
            }
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            int n = listBox1.Items.Count;
            for (int i = 0; i < n; i++)
            {
                {
                    listBox2.Items.Add(listBox1.Items[listBox1.Items.Count - 1]);
                    listBox1.Items.Remove(listBox1.Items[listBox1.Items.Count - 1]);
                }
            }
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox2);
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            sortAnylistBox(listBox2);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // listBox1.SelectedItems.Add(textBox1.Text);
            string input = textBox2.Text;
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (listBox1.Items[i].ToString() == input)
                {
                    listBox1.SetSelected(i, true); 
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // listBox1.SelectedItems.Remove(textBox3.Text);
            string input = textBox3.Text;
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (listBox1.Items[i].ToString() == input)
                {
                    listBox1.SetSelected(i, false);
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox5.Text = listBox1.Items.Count.ToString();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //textBox6.Text = listBox1.Items.Count.ToString();
            textBox6.Text = listBox1.SelectedItems.Count.ToString();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            // textBox7.Text = (listBox1.Items.Count - listBox1.SelectedItems.Count).ToString();
            int unselectedCount = listBox1.Items.Count - listBox1.SelectedItems.Count;
            textBox7.Text = unselectedCount.ToString();
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            /* if (listBox1.Items.Count > 0)
             {
                 for (int i = 0; i < listBox1.Items.Count; i++)
                 {
                     listBox1.SelectedIndex = i;
                 }
             }
             else
                 MessageBox.Show("not found elements");
         }*/
            if (listBox1.Items.Count > 0)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    listBox1.SetSelected(i, true);
                }
            }
            else
            {
                MessageBox.Show("لا توجد عناصر");
            }
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            
                var selectedItems = listBox1.SelectedItems.Cast<int>().OrderByDescending(x => x).ToList();
                foreach (var item in selectedItems)
                {
                    listBox1.Items.Remove(item);
                    listBox1.Items.Add(item);
                }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex != -1)
                listBox2.Items.RemoveAt(listBox2.SelectedIndex);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int index;
            if (int.TryParse(textBox4.Text, out index) && index >= 0 && index < listBox1.Items.Count)
            {
                listBox1.SetSelected(index, false); 
            }
            else
            {
                MessageBox.Show("الرجاء إدخال إندكس صحيح");
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
