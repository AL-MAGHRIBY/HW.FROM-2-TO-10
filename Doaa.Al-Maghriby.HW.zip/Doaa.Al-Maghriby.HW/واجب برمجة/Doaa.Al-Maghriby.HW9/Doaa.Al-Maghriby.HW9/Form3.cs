﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW9
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new string[] { "+", "-", "*", "/" });
            textBox3.ReadOnly = true;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true; 
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = Convert.ToDouble(textBox1.Text);
                double num2 = Convert.ToDouble(textBox2.Text);
                string operation = comboBox1.SelectedItem?.ToString();
                double result = 0;

                if (operation == null)
                {
                    MessageBox.Show("الرجاء اختيار عملية");
                    return;
                }

                switch (operation)
                {
                    case "+":
                        result = num1 + num2;
                        break;
                    case "-":
                        result = num1 - num2;
                        break;
                    case "*":
                        result = num1 * num2;
                        break;
                    case "/":
                        if (num2 == 0)
                        {
                            MessageBox.Show("لا يمكن القسمة على صفر", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        result = num1 / num2;
                        break;
                }

                // عرض النتيجة في textBox3
                textBox3.Text = result.ToString();

                // إضافة الأجزاء المختلفة إلى كل ListBox
                listBox1.Items.Add(num1.ToString());
                listBox2.Items.Add(operation);
                listBox3.Items.Add(num2.ToString());
                listBox4.Items.Add(result.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("يرجى إدخال أرقام صحيحة في الحقول.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1)
            {
                listBox1.Items.RemoveAt(selectedIndex);
                listBox2.Items.RemoveAt(selectedIndex);
                listBox3.Items.RemoveAt(selectedIndex);
                listBox4.Items.RemoveAt(selectedIndex);
            }
            else
            {
                MessageBox.Show("يرجى تحديد عنصر للحذف.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1)
            {
                // تحديث TextBoxات الحساب بناءً على العنصر المحدد
                textBox1.Text = listBox1.Items[selectedIndex].ToString();
                comboBox1.SelectedItem = listBox2.Items[selectedIndex].ToString();
                textBox2.Text = listBox3.Items[selectedIndex].ToString();
                textBox3.Text = listBox4.Items[selectedIndex].ToString();
            }
            else
            {
                MessageBox.Show("يرجى تحديد عنصر للتعديل.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
