﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW9
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        // التحقق إذا كان المدخل رقم
        bool IsNumeric(string input)
        {
            int number;
            return int.TryParse(input, out number);
        }

        // التحقق إذا كان العمر صالحًا (رقم وأقل من 130)
        bool IsValidAge(string age)
        {
            if (IsNumeric(age))
            {
                int num = int.Parse(age);
                return num <= 130 && num >= 0;
            }
            return false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!IsNumeric(textBox1.Text))
            {
                MessageBox.Show("الرجاء إدخال رقم صالح.");
                return;
            }

            // التحقق من اسم الطالب
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("الرجاء إدخال اسم الطالب.");
                return;
            }

            // التحقق من العمر
            if (!IsValidAge(textBox3.Text))
            {
                MessageBox.Show("الرجاء إدخال عمر صالح (أقل من 130).");
                return;
            }

            // التحقق من الجنس
            string gender = radioButton1.Checked ? "ذكر" : (radioButton2.Checked ? "أنثى" : string.Empty);
            if (string.IsNullOrEmpty(gender))
            {
                MessageBox.Show("الرجاء تحديد الجنس.");
                return;
            }

            // إضافة القيم إلى الـ ListBoxes
            listBox1.Items.Add(textBox1.Text);  // إضافة الرقم
            listBox2.Items.Add(textBox2.Text);  // إضافة الاسم
            listBox3.Items.Add(textBox3.Text);  // إضافة العمر
            listBox4.Items.Add(gender);         // إضافة الجنس

            // مسح محتويات TextBoxes بعد الإضافة
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // حذف العنصر المحدد من الـ ListBoxes
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1)
            {
                listBox1.Items.RemoveAt(selectedIndex);
                listBox2.Items.RemoveAt(selectedIndex);
                listBox3.Items.RemoveAt(selectedIndex);
                listBox4.Items.RemoveAt(selectedIndex);
            }
            else
            {
                MessageBox.Show("الرجاء اختيار عنصر لحذفه.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1)
            {
                // التحقق من الرقم
                if (!IsNumeric(textBox1.Text))
                {
                    MessageBox.Show("الرجاء إدخال رقم صالح.");
                    return;
                }

                // التحقق من اسم الطالب
                if (string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("الرجاء إدخال اسم الطالب.");
                    return;
                }

                // التحقق من العمر
                if (!IsValidAge(textBox3.Text))
                {
                    MessageBox.Show("الرجاء إدخال عمر صالح (أقل من 130).");
                    return;
                }

                // التحقق من الجنس
                string gender = radioButton1.Checked ? "ذكر" : (radioButton2.Checked ? "أنثى" : string.Empty);
                if (string.IsNullOrEmpty(gender))
                {
                    MessageBox.Show("الرجاء تحديد الجنس.");
                    return;
                }

                // تعديل القيم في الـ ListBoxes
                listBox1.Items[selectedIndex] = textBox1.Text;  // تعديل الرقم
                listBox2.Items[selectedIndex] = textBox2.Text;  // تعديل الاسم
                listBox3.Items[selectedIndex] = textBox3.Text;  // تعديل العمر
                listBox4.Items[selectedIndex] = gender;         // تعديل الجنس

                // مسح محتويات TextBoxes بعد التعديل
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                radioButton1.Checked = false;
                radioButton2.Checked = false;
            }
            else
            {
                MessageBox.Show("الرجاء اختيار عنصر للتعديل عليه.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true; 
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true; 
            }
        }
    }
}
