﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doaa.Al_Maghriby.HW10الثاني
{
    public class Student
    {
        private int number;
        private string name;
        private string birthdate;
        private string imgpath;

        public void setnumber(int number)
        {
            this.number = number;
        }
        public void setname(string name)
        {
            this.name = name;
        }

        public void setbirthdate(string birthdate)
        {
            this.birthdate = birthdate;
        }

        public void setimgpath(string imgpath)
        {
            this.imgpath = imgpath;
        }

        public int getnumber()
        {
            return number;
        }

        public string getname() => name;
        public string getbirthdate() => birthdate;
        public string getimgpath() => imgpath;
    }
}

