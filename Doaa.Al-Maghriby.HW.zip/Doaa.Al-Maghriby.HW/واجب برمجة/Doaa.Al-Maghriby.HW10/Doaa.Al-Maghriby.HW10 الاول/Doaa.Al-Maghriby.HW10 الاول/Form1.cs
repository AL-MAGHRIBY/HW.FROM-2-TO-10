﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Doaa.Al_Maghriby.HW10_الاول
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Items.Add("*.png");
            comboBox1.Items.Add("*.jpg");
            comboBox1.Items.Add("*.jpeg");
            comboBox1.Items.Add("*.txt");
            comboBox1.Items.Add("*.*");
            comboBox1.SelectedIndex = 1;
        }

        private void dirListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fileListBox1.Path = dirListBox1.Path;
        }

        private void driveListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dirListBox1.Path = driveListBox1.Drive;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fileListBox1.Pattern = comboBox1.Text.Trim();
        }

        private void fileListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filePath = Path.Combine(fileListBox1.Path, fileListBox1.FileName);
            label4.Text = filePath;
            label5.Text = Path.GetFileName(filePath);
            label6.Text = Path.GetExtension(filePath);

            // Clear previous content
            richTextBox1.Clear();
            pictureBox1.Image = null;

            try
            {
                if (label6.Text.Trim().ToLower() == ".txt")
                {
                    // Display text file content in richTextBox1
                    richTextBox1.Text = File.ReadAllText(filePath);
                }
                else if (label6.Text.ToLower() == ".png" || label6.Text.ToLower() == ".jpg" || label6.Text.ToLower() == ".jpeg")
                {
                    // Display image in pictureBox1 without locking the file
                    using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    {
                        pictureBox1.Image = Image.FromStream(fs);
                    }
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            /*
           label4.Text = fileListBox1.Path + "\\" + fileListBox1.FileName;
           label5.Text = Path.GetFileName(label4.Text);
           //label5.Text=fileListBox1.FileName;
           label6.Text = Path.GetExtension(label4.Text);
           if (label6.Text.Trim().ToLower() == ".txt")
           {
               richTextBox1.Text = File.ReadAllText(label4.Text);
               pictureBox1.Image = null;
              // pictureBox1.Visible = false;
           }
           else if (label6.Text.ToLower() == ".png" || label6.Text.ToLower() == ".jpg" || label6.Text.Trim().ToLower() == ".jpeg")
           {
               pictureBox1.Image = Image.FromFile(label4.Text);
             //  pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
               richTextBox1.Text = "  ";
              // richTextBox1.Visible = false;*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
