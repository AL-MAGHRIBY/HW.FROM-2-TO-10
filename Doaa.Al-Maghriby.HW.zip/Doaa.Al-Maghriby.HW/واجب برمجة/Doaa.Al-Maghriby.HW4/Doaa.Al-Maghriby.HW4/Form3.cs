﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                for (int i = 0; i < Top; i++)
                {
                    if (checkBox1.Checked)
                        button1.Top -= Convert.ToInt16(checkBox1.Text);
                    else if (checkBox2.Checked)
                        button1.Top -= Convert.ToInt32(checkBox2.Text);
                    else if (checkBox3.Checked)
                        button1.Top -= Convert.ToInt32(checkBox3.Text);
                    else if (checkBox4.Checked)
                        button1.Top -= Convert.ToInt32(checkBox4.Text);
                    for (int j = 0; j < 100000000; j++) ;
                }
            else
               if (radioButton2.Checked)
                for (int i = 0; i < Top; i++)
                {
                    if (checkBox1.Checked)
                        button1.Top += Convert.ToInt16(checkBox1.Text);
                    else if (checkBox2.Checked)
                        button1.Top += Convert.ToInt32(checkBox2.Text);
                    else if (checkBox3.Checked)
                        button1.Top += Convert.ToInt32(checkBox3.Text);
                    else if (checkBox4.Checked)
                        button1.Top += Convert.ToInt32(checkBox4.Text);
                    for (int j = 0; j < 100000000; j++) ;
                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Top -= 5;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button1.Size = new Size(button1.Width, button1.Height + 5);
            //button1.Height += 5;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button1.Height -= 5;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.Location = new Point(button1.Left, button1.Top + 5);
            //button1.Top += 5;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button1.Width += 5;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Left += 5;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button1.Width -= 5;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button1.Left -= 5;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            this.Hide();
            form4.Show();
        }
    }
}
