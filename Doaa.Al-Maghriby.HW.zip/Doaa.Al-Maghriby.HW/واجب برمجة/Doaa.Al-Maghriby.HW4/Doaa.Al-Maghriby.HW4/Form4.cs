﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW4
{
    public partial class Form4 : Form
    {
        int[] a;
        int m = 0, i = 0;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            textBox3.Enabled = textBox2.Enabled = button1.Enabled = listBox1.Enabled = button2.Enabled = false;
            textBox3.KeyPress += textBox2_KeyPress;
            textBox1.KeyPress += textBox2_KeyPress;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
                e.Handled = true;
        }
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (sender == textBox3 || sender == textBox1)
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
                    e.Handled = true;
            }
            if (sender == textBox2)
            {
                if ((e.KeyChar < 65 || e.KeyChar > 122) && (e.KeyChar != 8))
                    e.Handled = true;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox3.Text.Trim() != "" && textBox2.Text.Trim() != "")
            {
                if (i < m)
                {
                    listBox1.Items.Add(textBox2.Text + "\t" + textBox3.Text);
                    a[i++] = int.Parse(textBox3.Text);
                    textBox3.Text = textBox2.Text = "";
                    textBox3.Focus();
                    textBox2.Focus();


                }
                else
                    MessageBox.Show("The array is Full ");
            }
            else
                MessageBox.Show("Error In TextBox ");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox3.Enabled = textBox2.Enabled = button1.Enabled = listBox1.Enabled = button2.Enabled = textBox1.Text.Trim() != "";
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
            {
                m = int.Parse(textBox1.Text);
                a = new int[m];
                i = 0;
            }
            listBox1.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int b = listBox1.Items.Count, temp = a[0];
            string st = "";
            if (b > 0)
            {
                for (int k = 0; k < i; k++)
                {
                    for (int j = k + 1; j < i; j++)
                    {
                        if (a[k] > a[j])
                        {
                            temp = a[k];
                            a[k] = a[j];
                            a[j] = temp;
                            st = listBox1.Items[k].ToString();
                            listBox1.Items[k] = listBox1.Items[j].ToString();
                            listBox1.Items[j] = st.ToString();
                        }
                    }
                }
            }
            else
                MessageBox.Show(" The List is Empty..!");
        }
    }
}

