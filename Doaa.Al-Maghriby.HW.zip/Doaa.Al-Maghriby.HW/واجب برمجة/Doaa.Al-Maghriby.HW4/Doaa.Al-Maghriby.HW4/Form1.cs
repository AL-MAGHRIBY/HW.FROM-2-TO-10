﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("انقر على الواجهة للحصول على الوان مختلفة ", "Hello",
               MessageBoxButtons.OKCancel);
            this.CenterToParent();
            textBox2.Text = "Doaa Hassan AL-Maghriby" + "\r\n";
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Random r = new Random();
            this.BackColor = Color.FromArgb(r.Next(0, 255), r.Next(0, 255),
                r.Next(0, 255));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
                textBox1.BackColor = Color.Pink;
            else
                textBox1.BackColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "" && !IsNumber(textBox1.Text)) 
            {
                textBox2.Text += textBox1.Text + "\r\n".ToString();
                textBox1.Focus();
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Error in TextBox ..!");
                textBox1.Focus();
                textBox1.Clear();
            }
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.Purple;
            button1.BackColor = Color.Yellow;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gray;
            button1.ForeColor = Color.White;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("مع السلامة ");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool IsNumber(string s)
        {
            for (int i = 0; i < s.Length; i++)
                if (s[i] >= 48 && s[i] <= 57)
                    return true;
            return false;
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Black;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            this.Hide();
            form2.Show();
        }
    }
    }

