﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW6
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            BackgroundImage = Image.FromFile(@"C:\Users\المرتضى\Desktop\MY folder\C#\واجب برمجة\Doaa.Al-Maghriby.HW6\dodo.png");
            BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Image = Image.FromFile(@"C:\Users\المرتضى\Desktop\MY folder\C#\واجب برمجة\Doaa.Al-Maghriby.HW6\dodo.png");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        int i = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            i++;
            if (i <= 8)
            {
                pictureBox1.Image = Image.FromFile(i.ToString() + ".png");
                BackgroundImage = Image.FromFile(i.ToString() + ".png");
            }

            else
                i = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            i--;
            if (i <= 0)
                i = 8;
            pictureBox1.Image = Image.FromFile(i.ToString() + ".png");
            BackgroundImage = Image.FromFile(i.ToString() + ".png");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

