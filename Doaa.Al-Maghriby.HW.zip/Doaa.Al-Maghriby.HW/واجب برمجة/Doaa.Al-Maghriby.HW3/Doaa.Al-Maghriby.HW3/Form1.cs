﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double number1, number2, number3;
            string operation1 = textBox2.Text;
            string operation2 = textBox4.Text;
            string result1 = "";
            string result2 = "";
            if (double.TryParse(textBox1.Text, out number1) &&
                double.TryParse(textBox3.Text, out number2) &&
                double.TryParse(textBox5.Text, out number3))
            {
                result1 = performop(number1, number2, operation1).ToString();
                if (result1 == "nan")
                {
                    MessageBox.Show("العملية الاولى غير صحيحة ");
                    textBox2.Focus();
                    return;
                }
                result2 = performop(Convert.ToDouble(result1), number3, operation2).ToString();
                if (result2 == "nan")
                {
                    MessageBox.Show("العملية الثانية غير صحيحة ");
                    textBox4.Focus();
                    return;
                }
                textBox6.Text = result2.ToString();
            }
            else
            {
                MessageBox.Show("يرجى ادخال اعداد صحيحة");
            }
        }

        private double performop(double num1, double num2 , string operation)
        {
            switch(operation)
            { case "+": return num1 + num2;
              case "-": return num1 - num2;
              case "*": return num1 * num2;
              case "/": return  num2 != 0 ? num1 / num2 : double.NaN;
                default: return double.NaN;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             button1.Enabled = false;
             textBox6.ReadOnly = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = (textBox1.Text != "") && (textBox2.Text != "") && (textBox3.Text != "") && (textBox4.Text != "") && (textBox5.Text != "") ;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            this.Hide();
            form2.Show();
        }
    }
}
