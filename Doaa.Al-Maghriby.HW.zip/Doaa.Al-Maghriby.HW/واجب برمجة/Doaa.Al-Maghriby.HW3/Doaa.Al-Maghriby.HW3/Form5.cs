﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW3
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int number = Convert.ToInt32(textBox1.Text);
                int sum = 0;
                for (int i = 1; i <= number; i++)
                {
                    sum += i;
                }
              textBox2.Text = "the sum = " + sum;
            }
            catch (Exception)
            {
                MessageBox.Show("يرجى إدخال عدد صحيح", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int number = Convert.ToInt32(textBox1.Text);
                int factorial = 1;
                for (int i = 1; i <= number; i++)
                {
                    factorial *= i;
                }
                textBox2.Text = "Factorial = " + factorial;
            }
            catch (Exception)
            {
                MessageBox.Show("يرجى إدخال عدد صحيح", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                double number = Convert.ToDouble(textBox1.Text);
                if (number < 0)
                {
                    MessageBox.Show("الجذر التربيعي غير معرف للأعداد السالبة", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    double sqrt = Math.Sqrt(number);
                    textBox2.Text = " Square Root = " + sqrt;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("يرجى إدخال عدد صحيح", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
