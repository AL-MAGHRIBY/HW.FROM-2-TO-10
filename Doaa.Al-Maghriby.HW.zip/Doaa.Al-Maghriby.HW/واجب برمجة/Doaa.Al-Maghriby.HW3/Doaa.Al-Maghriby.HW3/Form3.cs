﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW3
{
    public partial class Form3: Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void traingforsender(object sender, EventArgs e)
        {
            if (sender == button1)
                button4.BackColor = Color.Pink;
            else if (sender == button2)
                button4.BackColor = Color.Purple;
            else if (sender == button3)
                button4.BackColor = Color.Brown;
            else if (((Label)sender).Text == "label1")
                button4.Text = label1.Text;
            else if (((Label)sender).Text == "label2")
                button4.Text = label2.Text;
            /* 
      (is) يمكننا معرفة نوع الأداة التي تم الضغط عليها باستخدام عبارة 
      كالتالي : 

      private void traingforsender(object sender, EventArgs e)
{
    if (sender is Button button) // تحقق إذا كان sender من نوع Button
    {
        // التعامل مع الأداة إذا كانت زر
        MessageBox.Show("زر تم الضغط عليه: " + button.Name);
    }
    else if (sender is Label label) // تحقق إذا كان sender من نوع Label
    {
        // التعامل مع الأداة إذا كانت تسمية (Label)
        MessageBox.Show("تسمية تم الضغط عليها: " + label.Text);
    }
} */
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            this.Hide();
            form4.Show();

        }

       

    }
}
