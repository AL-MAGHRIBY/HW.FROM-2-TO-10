﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW3
{
    public partial class Form4 : Form
    {
        double x, y, z;

        public Form4()
        {
            InitializeComponent();
            // إضافة العمليات إلى ListBox
            listBox1.Items.Add("+");
            listBox1.Items.Add("-");
            listBox1.Items.Add("*");
            listBox1.Items.Add("/");
            listBox1.SelectedIndex = 0; // تعيين العملية الافتراضية إلى الجمع
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // الحدث الذي يتم تشغيله عند اختيار عملية من ListBox
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            PerformCalculation();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = null;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            textBox3.ReadOnly = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            PerformCalculation();
        }

        private void PerformCalculation()
        {
            try
            {
                // تحويل النص من TextBox إلى أرقام
                x = Convert.ToDouble(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الأول غير صالح", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox1.Text = "";
                textBox1.Focus();
                return;
            }
            try
            {
                y = Convert.ToDouble(textBox2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الثاني غير صالح", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox2.Text = "";
                textBox2.Focus();
                return;
            }

            bool validOperation = true;
            switch (listBox1.SelectedIndex) // تنفيذ العملية بناءً على الاختيار في ListBox
            {
                case 0: z = x + y; break; 
                case 1: z = x - y; break; 
                case 2: z = x * y; break; 
                case 3:
                    if (y != 0) // التحقق من عدم القسمة على صفر
                    {
                        z = x / y;
                    }
                    else
                    {
                        MessageBox.Show("لا يمكن القسمة على صفر");
                        validOperation = false;
                        textBox3.Text = null;
                    }
                    break;
            }

            if (validOperation)
                textBox3.Text = z.ToString(); 
        }
    }
}
