﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            panel1.Visible = panel2.Visible = panel3.Visible = panel4.Visible = false;
            panel1.Location = panel2.Location = panel3.Location = panel4.Location = new Point(1, 60);
            this.Height = button3.Height + 50;
            this.Width = button4.Left + button4.Width + 40;

            button7.Click += button6_Click;
            button9.Click += button6_Click;
            button11.Click += button6_Click;

            textBox2.KeyPress += textBox3_KeyPress;
            textBox3.KeyPress += textBox3_KeyPress;
            textBox4.KeyPress += textBox3_KeyPress;
            textBox5.KeyPress += textBox3_KeyPress;
            textBox6.KeyPress += textBox3_KeyPress;
            textBox7.KeyPress += textBox3_KeyPress;
            textBox8.KeyPress += textBox3_KeyPress;
            textBox9.KeyPress += textBox3_KeyPress;
            textBox10.KeyPress += textBox3_KeyPress;
            textBox11.KeyPress += textBox3_KeyPress;
            textBox12.KeyPress += textBox3_KeyPress;
        }

        

        

        
        

        
       
        

        

        

        

        
        //
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form4_Load(null, null);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            this.Height = panel2.Height * 2;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            panel1.Visible =true;
            panel2.Visible =false;
            panel3.Visible =false;
            panel4.Visible =false;
           Height = panel2.Height*2;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            panel1.Visible = false;
            panel2.Visible = false;
            panel4.Visible = false;
            Height = panel2.Height * 2;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            Height = panel2.Height * 2;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text.Trim() != "") && (textBox2.Text.Trim() != ""))
                textBox3.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) + Convert.ToInt32(textBox2.Text));
            else
                MessageBox.Show("ادخل رقما"); 

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if ((textBox6.Text.Trim() != "") && (textBox5.Text.Trim() != ""))
                textBox4.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) - Convert.ToInt32(textBox2.Text));
            else
                MessageBox.Show("ادخل رقما");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if ((textBox9.Text.Trim() != "") && (textBox8.Text.Trim() != ""))
                textBox7.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) * Convert.ToInt32(textBox2.Text));
            else
                MessageBox.Show("ادخل رقما");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if ((textBox12.Text.Trim() != "") && (textBox11.Text.Trim() != ""))
                textBox10.Text = Convert.ToString(Convert.ToInt32(textBox1.Text));
        } 
      
    }
}
