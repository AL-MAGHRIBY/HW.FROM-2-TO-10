﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool f = false;
            int s = 0;
            textBox1.Text = null;
            if (checkBox1.Checked)
            {
                s += 100;
                f = true;
            
            }
            if (checkBox2.Checked)
            {
                s += 200;
                f = true;

            }
            if (checkBox3.Checked)
            {
                s += 300;
                f = true;

            }
            if (checkBox4.Checked)
            {
                s += 400;
                f = true;

            }
            if (checkBox5.Checked)
            {
                s += 500;
                f = true;

            }
            if (f)
                textBox1.Text=s.ToString();

           // else
           // {
            //    textBox1.Clear();
             //   MessageBox.Show("eror");
            //}
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                label3.ForeColor = Color.Red;
            else if (radioButton2.Checked)
                label3.ForeColor = Color.Yellow;
            else if (radioButton3.Checked)
                label3.ForeColor = Color.Green;
            else if (radioButton4.Checked)
                label3.ForeColor = Color.Black;
            ///........................................
            if (radioButton5.Checked)
                label3.BackColor = Color.Red;
            else if (radioButton6.Checked)
                label3.BackColor = Color.Yellow;
            else if (radioButton7.Checked)
                label3.BackColor = Color.Green;
            else if (radioButton8.Checked)
                label3.BackColor = Color.Black;

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Enabled = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
