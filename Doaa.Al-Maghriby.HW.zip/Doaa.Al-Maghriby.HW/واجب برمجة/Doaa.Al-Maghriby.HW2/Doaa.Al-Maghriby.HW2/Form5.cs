﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            textBox3.BackColor = Color.Blue;
            EnableButtons(false);
        }

        public void IsNumber(KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }
        public void EnableButtons(bool isEnabled)
        {
            button1.Enabled = isEnabled;
            button2.Enabled = isEnabled;
            button3.Enabled = isEnabled;
            button4.Enabled = isEnabled;
        }
        public void PerformOperation(double n1, double n2, string op)
        {
            switch (op)
            {
                case "+":
                    textBox3.Text = (n1 + n2).ToString();
                    textBox3.BackColor = Color.White;
                    break;
                case "-":
                    textBox3.Text = (n1 - n2).ToString();
                    textBox3.BackColor = Color.White;
                    break;
                case "*":
                    textBox3.Text = (n1 * n2).ToString();
                    textBox3.BackColor = Color.White;
                    break;
                case "/":
                    if (n2 != 0)
                    {
                        textBox3.Text = (n1 / n2).ToString();
                        textBox3.BackColor = Color.White;
                    }
                    else
                    {
                        MessageBox.Show("لا يمكن القسمة على صفر", "تحذير", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button3);
                    }
                    break;
                default:
                    textBox3.BackColor = Color.Black;
                    MessageBox.Show("عملية غير معروفة", "خطأ", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button3);
                    break;
            }
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            textBox2.TextChanged += Txt_TextChanged;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PerformOperation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "+");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PerformOperation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "-");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PerformOperation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "*");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PerformOperation(double.Parse(textBox1.Text), double.Parse(textBox2.Text), "/");
        }
        private void Txt_TextChanged(object sender, EventArgs e)
        {
            bool isEnabled = (textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "");
            EnableButtons(isEnabled);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            IsNumber(e);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            IsNumber(e);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            this.Hide();
            form6.Show();
        }
    }
}
