﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Text = (Convert.ToDouble(textBox1.Text) + Convert.ToDouble(textBox2.Text)).ToString();
            textBox3.BackColor = Color.Red;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //تم تضعيف الحدث 
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = button4.Enabled = button5.Enabled = button6.Enabled =
                       (textBox1.Text != "") && (textBox2.Text != "");
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            textBox1.TextChanged += textBox2_TextChanged;
            button1.Enabled = button4.Enabled = button5.Enabled = button6.Enabled = false;
            textBox3.ReadOnly = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox3.Text = (Convert.ToDouble(textBox1.Text) - Convert.ToDouble(textBox2.Text)).ToString();
            textBox3.BackColor = Color.Red;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox3.Text = (Convert.ToDouble(textBox1.Text) / Convert.ToDouble(textBox2.Text)).ToString();
            textBox3.BackColor = Color.Red;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox3.Text = (Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox2.Text)).ToString();
            textBox3.BackColor = Color.Red;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }
    }
}
