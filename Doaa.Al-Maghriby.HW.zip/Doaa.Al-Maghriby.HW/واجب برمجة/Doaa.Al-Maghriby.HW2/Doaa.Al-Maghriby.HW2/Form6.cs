﻿using System;
using System.Windows.Forms;

namespace Doaa.Al_Maghriby.HW2
{
    public partial class Form6 : Form
    {
        double x, y, z;
        string[] op = { "+", "-", "*", "/" };

        public Form6()
        {
            InitializeComponent();
            combobox1.Items.Add("+");
            combobox1.Items.Add("-");
            combobox1.Items.Add("*");
            combobox1.Items.Add("/");
            combobox1.SelectedIndex = 0;
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            textBox3.ReadOnly = true;
            combobox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = null;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                x = Convert.ToDouble(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الأول غير صالح", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox1.Text = "";
                textBox1.Focus();
                return;
            }
            try
            {
                y = Convert.ToDouble(textBox2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الثاني غير صالح", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox2.Text = "";
                textBox2.Focus();
                return;
            }
            bool f = true;
            switch (combobox1.SelectedIndex)
            {
                case 0: z = x + y; break;
                case 1: z = x - y; break;
                case 2: z = x * y; break;
                case 3:
                    if (y != 0)
                    {
                        z = x / y;
                    }
                    else
                    {
                        MessageBox.Show("لا يمكن القسمة على صفر");
                        f = false;
                        textBox3.Text = null;
                    }
                    break;
            }
            if (f)
                textBox3.Text = z.ToString();
        }
    }
}
